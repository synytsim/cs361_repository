open console
type:
"npm install"
enter
"npm run start"
enter

open browser and navigate to "localhost:3000"
